/* 
 * File:   main.cpp
 * Author: Anh Vu
 * Purpose: Savitch Ch1 Prob7
 * Created on June 25, 2014, 4:31 PM
 */

//System Level Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
//Output Border and message
    cout<<"*******************************************************\n";
    cout<<endl;
    cout<<"            C C C          S S S S       !!\n";
    cout<<"          C       C       S       S      !!\n";
    cout<<"         C               S               !!\n";
    cout<<"        C                 S              !!\n";
    cout<<"        C                  S S S S       !!\n";
    cout<<"        C                          S     !!\n";
    cout<<"         C                          S    !!\n";
    cout<<"          C       C      S         S       \n";
    cout<<"            C C C          S S S S       00\n";
    cout<<endl;
    cout<<"*******************************************************\n";
    cout<< endl;
    cout<<"Computer Science is Cool Stuff!!!\n";
    
//Exit Stage Right!
    return 0;
}

