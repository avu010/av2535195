/* 
 * File:   main.cpp
 * Author: Anh Vu  
 * Purpose: First Hmwk
 * Created on June 24, 2014, 7:32 PM
 */

#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes 

//Execution Begins Here!
int main(int argc, char** argv) {
//Output Simple Text
    cout<<"Hello World"<<endl;
    //Exit Stage Right!
    return 0;
}

